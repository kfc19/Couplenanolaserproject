#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 14:32:36 2023

@author: riccardonori
"""

import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
from numpy import linalg as la
from scipy import optimize as op
from tqdm import tqdm
from time import sleep
import math
from matplotlib.collections import LineCollection
from matplotlib.colors import ListedColormap, BoundaryNorm
import matplotlib.colors

params={'figure.figsize': [25, 20],
        'font.size': 24,
        'font.serif': 'Calibri'}
plt.rcParams.update(params)


class Complex:
    
    def __init__(self, omega_a = 0, omega_b = 0, gamma_a = 0, gamma_b = 0, Da = np.linspace(0,10,101), Db = np.linspace(0,10,101), kappa_ab = 1, kappa_ba = 1, phi_ab = 0, phi_ba = 0):
        
        self._omega_a = omega_a
        self._omega_b = omega_b
        self._gamma_a = gamma_a
        self._gamma_b = gamma_b
        self._Da = Da
        self._Db = Db
        self._kappa_ab = kappa_ab
        self._kappa_ba = kappa_ba
        self._phi_ab = phi_ab
        self._phi_ba = phi_ba
        
    def set_matrix(self):
        
        
        if type(self._phi_ab) != int and type(self._phi_ab) != float:
            
            phi_ab_grid, phi_ba_grid = np.meshgrid(self._phi_ab, self._phi_ba)
            
            a = self._omega_a - self._gamma_a*1j + self._Da*1j
            b = self._kappa_ab * np.exp(1j * phi_ab_grid)
            c = self._kappa_ba * np.exp(1j * phi_ba_grid)
            d = self._omega_b - self._gamma_b*1j + self._Db*1j
            
            shape = b.shape

        
        else:
        
            Da_grid, Db_grid = np.meshgrid(self._Da, self._Db)
            
            a = self._omega_a - self._gamma_a*1j + Da_grid*1j
            b = self._kappa_ab * np.exp(1j*self._phi_ab)
            c = self._kappa_ba * np.exp(1j*self._phi_ba)
            d = self._omega_b - self._gamma_b*1j + Db_grid*1j
            
            shape = a.shape
        
        M = np.zeros((*shape, 2, 2), dtype='complex128')
        #print(M)
        M[...,0,0] = a
        M[...,0,1] = b
        M[...,1,0] = c
        M[...,1,1] = d
        
        return M
    
    
    def matrix_solve(self):
        
        M = self.set_matrix()
        val, vec = la.eig(M)
        
        imval = np.imag(val)
        idx = np.argsort(imval)
        
        val = np.take_along_axis(val, idx, axis=-1)
        
        # value_1 = val[...,0].flatten()
        # value_2 = val[...,1].flatten()
        # vec_1 = vec[...,0]
        # vec_2 = vec[...,1]
        
        # val_1 = []
        # val_2 = []
        
        # for i in range(len(value_1)):
        #     if np.imag(value_1[i]) < np.imag(value_2[i]):
        #         val_1.append(value_1[i])
        #         val_2.append(value_2[i])
        #     if np.imag(value_2[i]) < np.imag(value_1[i]):
        #         val_1.append(value_2[i])
        #         val_2.append(value_1[i])
        #     if np.imag(value_1[i]) == np.imag(value_2[i]):
        #         val_1.append(value_1[i])
        #         val_2.append(value_2[i])
        
        
        return val[...,0], val[...,1], vec[...,0], vec[...,1]
    
    
    def eigenvalue_plot(self):
            
        val_1, val_2, vec_1, vec_2 = self.matrix_solve()
        
        plt.set_cmap('viridis')
        plt.subplots(1, 2)
        
        # plt.subplot(2, 2, 1)
        plt.subplot(1,2,1)
        plt.pcolormesh(self._Da, self._Db, np.real(val_1), vmin = -1, vmax = 1, shading='gouraud')
        plt.colorbar(label='Coupled Frequency')
        plt.contour(self._Da, self._Db, np.imag(val_1), levels = 0)
        plt.contour(self._Da, self._Db, np.imag(val_2), levels = 0)
        plt.xlabel(r'$D_A$')
        plt.ylabel(r'$D_B$')
        # plt.title(r'$Re{\omega_1}$')
        
        # plt.subplot(2, 2, 2)
        plt.subplot(1,2,2)
        plt.pcolormesh(self._Da, self._Db, np.real(val_2), vmin = 0, shading='gouraud')
        plt.colorbar(label='Coupled Frequency')
        plt.contour(self._Da, self._Db, np.imag(val_1), levels = 0)
        plt.contour(self._Da, self._Db, np.imag(val_2), levels = 0)
        plt.xlabel(r'$D_A$')
        plt.ylabel(r'$D_B$')
        # plt.title(r'$Im{\omega_1}$')
        
        # plt.subplot(2, 2, 3)
        # plt.pcolormesh(self._Da, self._Db, np.real(val_2), vmin = -1, vmax = 1, shading='gouraud')
        # plt.colorbar(label='Coupled Frequency')
        # plt.xlabel(r'$D_A$')
        # plt.ylabel(r'$D_B$')
        # plt.title(r'$Re{\omega_2}$')
        
        # plt.subplot(2, 2, 4)
        # plt.pcolormesh(self._Da, self._Db, np.imag(val_2), vmin = 0, shading='gouraud')
        # plt.colorbar(label='Coupled Frequency')
        # plt.contour(self._Da, self._Db, np.imag(val_2), levels = 1)
        # plt.xlabel(r'$D_A$')
        # plt.ylabel(r'$D_B$')
        # plt.title(r'$Im{\omega_2}$')
        
        plt.tight_layout()
        plt.show()
            
    def threshold_contour(self):
        
        val_1, val_2, vec_1, vec_2 = self.matrix_solve()
            
        plt.set_cmap('ocean_r')
        plt.contour(self._Da, self._Db, np.imag(val_1), levels = 0, colors = 'orange')
        plt.contour(self._Da, self._Db, np.imag(val_2), levels = 0, colors = 'blue')
        plt.xlabel(r'$D_A$')
        plt.ylabel(r'$D_B$')
        plt.grid()
        plt.gca().set_aspect('equal')
        plt.title('Threshold Contour Lines')
        plt.show()
        
        
    def threshold_lines(self, phi = None, N=101):
        
        omega_a = self._omega_a
        omega_b = self._omega_b
        
        gamma_a = self._gamma_a
        gamma_b = self._gamma_b

        kappa_ab = self._kappa_ab
        kappa_ba = self._kappa_ba
        
        if phi == None:
            phi_ab = self._phi_ab
            phi_ba = self._phi_ba
        
        else:
            phi_ab = phi
            phi_ba = phi
        
        def mode_boundary(Delta, omega_a, omega_b, gamma_a, gamma_b, kappa_ab, kappa_ba, phi_ab, phi_ba):
            
            a = omega_a + 1j*(Delta/2)
            b = kappa_ab * np.exp(1j * phi_ab)
            c = kappa_ba * np.exp(1j * phi_ba)
            d = omega_b - 1j*(Delta/2)
    
            # M = np.zeros((2, 2), dtype='complex128')

            # M[...,0,0] = a
            # M[...,0,1] = b
            # M[...,1,0] = c
            # M[...,1,1] = d
            
            # val, vec = la.eig(M)
            
            # lam = val
            # lam = np.moveaxis(lam, -1, 0)
            # lam = np.sort(np.imag(lam), 0)
            
            # return -1*lam
            
            kr = np.real(4*b*c)
            ki = np.imag(4*b*c)
            delta = np.real(a - d)
            
            discr = a**2 - 2*a*d + 4*b*c + d**2
        
            # if np.imag(discr) == 0 and np.real(discr) < 0 and np.imag(a - d) < 0:
            if (delta != 0 and np.imag(discr) < 0 and (kr + delta**2 - (ki/2/delta)**2) < 0) or (delta == 0 and ki == 0 and kr > 0 and np.real(discr) < 0 and np.imag(a-d) > 0):
                lambda_1 = (1/2) * (1*np.sqrt(discr) + a + d)
                lambda_2 = (1/2) * (-1*np.sqrt(discr) + a + d)
            else:
                lambda_1 = (1/2) * (-1*np.sqrt(discr) + a + d)
                lambda_2 = (1/2) * (1*np.sqrt(discr) + a + d)
            
            return -1*np.imag(lambda_1), -1*np.imag(lambda_2)
        
        
        def DA(Delta, D, gamma_a):
            DA = D + gamma_a + Delta/2
            return DA
            
        def DB(Delta, D, gamma_b):
            DB = D + gamma_b - Delta/2
            return DB
        
        Delta = np.linspace(-10, 10, N)
        
        Da_1 = []
        Db_1 = []
        Da_2 = []
        Db_2 = []
        
        for i in range(len(Delta)):
                
            D = mode_boundary(
                Delta[i], omega_a, omega_b, gamma_a, gamma_b, 
                kappa_ab, kappa_ba, phi_ab, phi_ba)

            
            Da1 = DA(Delta[i], D[0], gamma_a)
            Db1 = DB(Delta[i], D[0], gamma_b)
            
            Da2 = DA(Delta[i], D[1], gamma_a)
            Db2 = DB(Delta[i], D[1], gamma_b)
            
            Da_1.append(Da1)
            Db_1.append(Db1)
            
            Da_2.append(Da2)
            Db_2.append(Db2)
            
        return Da_1, Db_1, Da_2, Db_2
    
    
    def threshold_line_points(self, Da_prime=None, Db_prime=None, mode_1=False, mode_2=False):
        
        omega_a = self._omega_a
        omega_b = self._omega_b
        
        gamma_a = self._gamma_a
        gamma_b = self._gamma_b

        kappa_ab = self._kappa_ab
        kappa_ba = self._kappa_ba
        
        phi_ab = self._phi_ab
        phi_ba = self._phi_ba
        

        Delta = np.linspace(-10, 10, 101)
        
        D_1_list = []
        D_2_list = []
        
        for i in range(len(Delta)):
            
            def mode_boundary(Delta, omega_a, omega_b, gamma_a, gamma_b, kappa_ab, kappa_ba, phi_ab, phi_ba):
                
                a = omega_a + 1j*(Delta/2)
                b = kappa_ab * np.exp(1j * phi_ab)
                c = kappa_ba * np.exp(1j * phi_ba)
                d = omega_b - 1j*(Delta/2)
        
                M = np.zeros((2, 2), dtype='complex128')

                M[...,0,0] = a
                M[...,0,1] = b
                M[...,1,0] = c
                M[...,1,1] = d
                
                val, vec = la.eig(M)
                
                lam = val
                lam = np.moveaxis(lam, -1, 0)
                lam = np.sort(np.imag(lam), 0)
                
                return -1*lam
            
            D = mode_boundary(Delta[i], omega_a, omega_b, gamma_a, gamma_b, kappa_ab, kappa_ba, phi_ab, phi_ba)
            D_1_list.append(D[0])
            D_2_list.append(D[1]) 
            
            if Da_prime != None:
                if mode_1 == True:
                    for i in range(len(D_1_list)):
                        Da = D_1_list[i] + gamma_a + Delta[i]/2
                        if (Da_prime - Da) < 1e-15:
                            Db = D_1_list[i] + gamma_b - Delta[i]/2
                            return Db
                if mode_2 == True:
                    for i in range(len(D_2_list)):
                        Da = D_2_list[i] + gamma_a + Delta[i]/2
                        if (Da_prime - Da) < 1e-15:
                            Db = D_2_list[i] + gamma_b - Delta[i]/2
                            return Db
            
            if Db_prime != None:
                if mode_1 == True:
                    for i in range(len(D_1_list)):
                        Db = D_1_list[i] + gamma_b - Delta[i]/2
                        if (Db_prime - Db) < 1e-15:
                            Da = D_1_list[i] + gamma_a + Delta[i]/2
                            return Da
                if mode_2 == True:
                    for i in range(len(D_2_list)):
                        Db = D_2_list[i] + gamma_b - Delta[i]/2
                        if (Db_prime - Db) < 1e-15:
                            Da = D_2_list[i] + gamma_a + Delta[i]/2
                            return Da
                
                
        
        
    def values_vectors(self, Da_prime_1, Db_prime_1, Da_prime_2, Db_prime_2):
        
        
        def mode_1(Da_prime_1, Db_prime_1):

            a = self._omega_a - self._gamma_a*1j + Da_prime_1*1j
            b = self._kappa_ab*np.exp(1j*self._phi_ab)
            c = self._kappa_ba*np.exp(1j*self._phi_ba)
            d = self._omega_b - self._gamma_b*1j + Db_prime_1*1j

            shape = a.shape
    
            M = np.zeros((*shape, 2, 2), dtype='complex128')

            M[...,0,0] = a
            M[...,0,1] = b
            M[...,1,0] = c
            M[...,1,1] = d
            
            val, vec = la.eig(M)
            
            if np.imag(val[...,0]) < np.imag(val[...,1]):
                return val[...,0], vec[...,0]
            else:
                return val[...,1], vec[...,1]
            
            # kr = np.real(4*b*c)
            # ki = np.imag(4*b*c)
            # delta = np.real(a - d)
            
            # discr = a**2 - 2*a*d + 4*b*c + d**2
        
            # # if np.imag(discr) == 0 and np.real(discr) < 0 and np.imag(a - d) < 0:
            # if (delta != 0 and np.imag(discr) < 0 and (kr + delta**2 - (ki/2/delta)**2) < 0) or (delta == 0 and ki == 0 and kr > 0 and np.real(discr) < 0 and np.imag(a-d) > 0):
            #     lambda_1 = (1/2) * (1*np.sqrt(discr) + a + d)
            #     vm = -((-a + d - np.sqrt(discr))/(2*c))
            #     one = np.ones(vm.shape)
            #     v1 = np.array([vm, one])
            # else:
            #     lambda_1 = (1/2) * (-1*np.sqrt(discr) + a + d)
            #     vp = -((-a + d + np.sqrt(discr))/(2*c))
            #     one = np.ones(vp.shape)
            #     v1 = np.array([vp, one])
                
            # return lambda_1, (1/la.norm(v1))*v1
                
                
                
            
        
        def mode_2(Da_prime_2, Db_prime_2):

            a = self._omega_a - self._gamma_a*1j + Da_prime_2*1j
            b = self._kappa_ab*np.exp(1j*self._phi_ab)
            c = self._kappa_ba*np.exp(1j*self._phi_ba)
            d = self._omega_b - self._gamma_b*1j + Db_prime_2*1j

            shape = a.shape

            M = np.zeros((*shape, 2, 2), dtype='complex128')
            #print(M)
            M[...,0,0] = a
            M[...,0,1] = b
            M[...,1,0] = c
            M[...,1,1] = d

            val, vec = la.eig(M)
            
            if np.imag(val[...,0]) < np.imag(val[...,1]):
                return val[...,1], vec[...,1]
            else:
                return val[...,0], vec[...,0]
            
            # kr = np.real(4*b*c)
            # ki = np.imag(4*b*c)
            # delta = np.real(a - d)
            
            # discr = a**2 - 2*a*d + 4*b*c + d**2
        
            # # if np.imag(discr) == 0 and np.real(discr) < 0 and np.imag(a - d) < 0:
            # if (delta != 0 and np.imag(discr) < 0 and (kr + delta**2 - (ki/2/delta)**2) < 0) or (delta == 0 and ki == 0 and kr > 0 and np.real(discr) < 0 and np.imag(a-d) > 0):
            #     lambda_2 = (1/2) * (-1*np.sqrt(discr) + a + d)
            #     vp = -((-a + d + np.sqrt(discr))/(2*c))
            #     one = np.ones(vp.shape)
            #     v2 = np.array([vp, one])
            # else:
            #     lambda_2 = (1/2) * (1*np.sqrt(discr) + a + d)
            #     vm = -((-a + d - np.sqrt(discr))/(2*c))
            #     one = np.ones(vm.shape)
            #     v2 = np.array([vm, one])
                
            # return lambda_2, (1/la.norm(v2))*v2
        
        return mode_1(Da_prime_1, Db_prime_1), mode_2(Da_prime_2, Db_prime_2)
    

    
    def line_plot(self):
        

        Da_prime_1, Db_prime_1, Da_prime_2, Db_prime_2 = self.threshold_lines()

        plt.figure(num=1)
        plt.plot(Da_prime_1, Db_prime_1, color = 'green', label = 'Mode 1')
        plt.plot(Da_prime_2, Db_prime_2, color = 'orange', label = 'Mode 2')

        
        for i in range(len(Da_prime_1)):
            
            x, y = self.values_vectors(Da_prime_1[i], Db_prime_1[i], Da_prime_2[i], Db_prime_2[i])
        
            def line_Da(r):
                Da = Da_prime_1[i]*(1 + r**2*np.abs(x[1][0])**2)
                return Da
        
            def line_Db(r):
                Db = Db_prime_1[i]*(1 + r**2*np.abs(x[1][1])**2)
                return Db
                
            r = np.linspace(0,10,100)
            
            plt.plot(line_Da(r), line_Db(r), color='red')

        plt.xlim(0,max(self._Da))
        plt.ylim(0,max(self._Db))
        plt.xlabel(r'$D_A$')
        plt.ylabel(r'$D_B$')
        plt.gca().set_aspect('equal')
        plt.grid()
        plt.legend()
        plt.show()
        
        
        plt.figure(num=2)
        plt.plot(Da_prime_1, Db_prime_1, color = 'green', label = 'Mode 1')
        plt.plot(Da_prime_2, Db_prime_2, color = 'orange' ,label = 'Mode 2')
            
        
        for i in range(len(Da_prime_2)):
            
            x, y = self.values_vectors(Da_prime_1[i], Db_prime_1[i], Da_prime_2[i], Db_prime_2[i])
        
            def line_Da(r):
                Da = Da_prime_2[i]*(1 + r**2*np.abs(y[1][0])**2)
                return Da
        
            def line_Db(r):
                Db = Db_prime_2[i]*(1 + r**2*np.abs(y[1][1])**2)
                return Db
                
                
            r = np.linspace(0,10,100)
                
            plt.plot(line_Da(r), line_Db(r), color='red')

        plt.xlim(0,max(self._Da))
        plt.ylim(0,max(self._Db))
        plt.xlabel(r'$D_A$')
        plt.ylabel(r'$D_B$')
        plt.gca().set_aspect('equal')
        plt.grid()
        plt.legend()
        plt.show()
        
    
    
    def Lasing_Mode_Selection(self, Da, Db, mode_id, Plot=True, fig_num = 20):
        
        omega_a = self._omega_a
        omega_b = self._omega_b
        
        gamma_a = self._gamma_a
        gamma_b = self._gamma_b
        
        kappa_ab = self._kappa_ab
        kappa_ba = self._kappa_ba
        
        phi_ab = self._phi_ab
        phi_ba = self._phi_ba
        
        Da_prime_1_old, Db_prime_1_old, Da_prime_2_old, Db_prime_2_old = self.threshold_lines()
        
        if Plot == True:
                    
            plt.figure(num=fig_num)
            # plt.title('Lasing Modes')
            plt.plot(Da_prime_1_old, Db_prime_1_old, color = 'green', label = 'Mode 1')
            plt.plot(Da_prime_2_old, Db_prime_2_old, color = 'orange', label = 'Mode 2')
            
            # iterate the implicit function over points on the threshold lines to find turning points
            
            def implicit_function(Da_prime, Db_prime, Da, Db):
                    psi_a = self.values_vectors(Da_prime, Db_prime, Da_prime, Db_prime)[0][1][0]
                    psi_b = self.values_vectors(Da_prime, Db_prime, Da_prime, Db_prime)[0][1][1]
                    f = Db_prime*(np.abs(psi_b)**2)*(Da_prime - Da) + Da_prime*(np.abs(psi_a)**2)*(Db - Db_prime)
                    return f
            
            if mode_id == 1:
                    
                Da_prime_new_1 = [] # 1 and 2 here refer to point 1 and point 2 i.e. consecutive points, not modes 1 and 2
                Db_prime_new_1 = []
                Da_prime_new_2 = []
                Db_prime_new_2 = []
                    
                for i in range(1,len(Db_prime_1_old)):
                    f = implicit_function(Da_prime_1_old[i], Db_prime_1_old[i], Da, Db)
                    f_minus = implicit_function(Da_prime_1_old[i-1], Db_prime_1_old[i-1], Da, Db)
                    # if np.sign(f) != np.sign(f_minus):
                    if (f < 0 and f_minus >= 0) or (f >= 0 and f_minus < 0):
                        Da_prime_new_1.append(Da_prime_1_old[i-1])
                        Db_prime_new_1.append(Db_prime_1_old[i-1])
                        Da_prime_new_2.append(Da_prime_1_old[i])
                        Db_prime_new_2.append(Db_prime_1_old[i])
                        
                        
            if mode_id == 2:
                    
                Da_prime_new_1 = []
                Db_prime_new_1 = []
                Da_prime_new_2 = []
                Db_prime_new_2 = []
                    
                for i in range(1,len(Db_prime_2_old)):
                    f = implicit_function(Da_prime_2_old[i], Db_prime_2_old[i], Da, Db)
                    f_minus = implicit_function(Da_prime_2_old[i-1], Db_prime_2_old[i-1], Da, Db)
                    # if np.sign(f) != np.sign(f_minus):
                    if (f < 0 and f_minus >= 0) or (f >= 0 and f_minus < 0):
                        Da_prime_new_1.append(Da_prime_2_old[i-1])
                        Db_prime_new_1.append(Db_prime_2_old[i-1])
                        Da_prime_new_2.append(Da_prime_2_old[i])
                        Db_prime_new_2.append(Db_prime_2_old[i])
                        
            # use average values to roughly identify turning point
            # avergae values will be used as initial guesses for fsolve            
            Da_prime_bar = (np.array(Da_prime_new_2) + np.array(Da_prime_new_1))/2  
            Db_prime_bar = (np.array(Db_prime_new_2) + np.array(Db_prime_new_1))/2

            
            def mode_condition(Delta, omega_a, omega_b, gamma_a, gamma_b, kappa_ab, kappa_ba, phi_ab, phi_ba, Da, Db):
                
                a = omega_a - 1j*gamma_a + 1j*(Delta/2)
                b = kappa_ab * np.exp(1j * phi_ab)
                c = kappa_ba * np.exp(1j * phi_ba)
                d = omega_b - 1j*gamma_b - 1j*(Delta/2)

                kr = np.real(4*b*c)
                ki = np.imag(4*b*c)
                delta = np.real(a - d)
                
                discr = a**2 - 2*a*d + 4*b*c + d**2
            
                # if np.imag(discr) == 0 and np.real(discr) < 0 and np.imag(a - d) < 0:
                if (delta != 0 and np.imag(discr) < 0 and (kr + delta**2 - (ki/2/delta)**2) < 0) or (delta == 0 and ki == 0 and kr > 0 and np.real(discr) < 0 and np.imag(a-d) > 0):
                    lambda_1 = (1/2) * (1*np.sqrt(discr) + a + d)
                    lambda_2 = (1/2) * (-1*np.sqrt(discr) + a + d)
                    vm = -((-a + d - np.sqrt(discr))/(2*c))
                    vp = -((-a + d + np.sqrt(discr))/(2*c))
                    one = np.ones(vm.shape)
                    v1 = np.array([vm, one])
                    v2 = np.array([vp, one])
                else:
                    lambda_1 = (1/2) * (-1*np.sqrt(discr) + a + d)
                    lambda_2 = (1/2) * (1*np.sqrt(discr) + a + d)
                    vm = -((-a + d - np.sqrt(discr))/(2*c))
                    vp = -((-a + d + np.sqrt(discr))/(2*c))
                    one = np.ones(vm.shape)
                    v1 = np.array([vp, one])
                    v2 = np.array([vm, one])
                
                    
                
                
                if mode_id == 1:
                    
                    vec_1 = (1/la.norm(v1))*v1
                    
                    D = -1*np.imag(lambda_1)
                    
                    psi_a = vec_1[0]
                    psi_b = vec_1[1]
                    
                    Da_prime = (1/2)*(2*D + Delta)
                    Db_prime = (1/2)*(2*D - Delta)
                    
                    f = Db_prime*(np.abs(psi_b)**2)*(Da_prime - Da) + Da_prime*(np.abs(psi_a)**2)*(Db - Db_prime)
                    return f
                
                if mode_id == 2:
                    
                    vec_2 = (1/la.norm(v2))*v2

                    D = -1*np.imag(lambda_2)
                    
                    psi_a = vec_2[0]
                    psi_b = vec_2[1]

                    Da_prime = (1/2)*(2*D + Delta)
                    Db_prime = (1/2)*(2*D - Delta)
                    
                    f = Db_prime*(np.abs(psi_b)**2)*(Da_prime - Da) + Da_prime*(np.abs(psi_a)**2)*(Db - Db_prime)
                    return f
            
            def line_Da_prime(r, psi_a):
                    Da = Da_prime*(1 + r**2*np.abs(psi_a)**2)
                    return Da
                
            def line_Db_prime(r, psi_b):
                Db = Db_prime*(1 + r**2*np.abs(psi_b)**2)
                return Db
            
            def eigenvector_amplitude(Da, Da_prime, psi_a):
                r = np.sqrt(((Da/Da_prime) - 1)/(np.abs(psi_a)**2))
                return r
            
            s = np.linspace(0,10,100)
            
            frequencies = []
            eigenvectors = []
            rs = []
            
            for i in range(len(Da_prime_bar)):
                
                initial_guess = Da_prime_bar[i] - Db_prime_bar[i] # Delta is differential pump
                
                Delta_root = op.fsolve(mode_condition, [initial_guess], args=(omega_a, omega_b, gamma_a, gamma_b, kappa_ab, kappa_ba, phi_ab, phi_ba, Da, Db))
                
                a = omega_a - 1j*gamma_a + 1j*(Delta_root/2)
                b = kappa_ab * np.exp(1j * phi_ab)
                c = kappa_ba * np.exp(1j * phi_ba)
                d = omega_b - 1j*gamma_b - 1j*(Delta_root/2)
                
                discr = a**2 - 2*a*d + 4*b*c + d**2
                
                kr = np.real(4*b*c)
                ki = np.imag(4*b*c)
                delta = np.real(a - d)
                
                if (delta != 0 and np.imag(discr) < 0 and (kr + delta**2 - (ki/2/delta)**2) < 0) or (delta == 0 and ki == 0 and kr > 0 and np.real(discr) < 0 and np.imag(a-d) > 0):
                    lambda_1 = (1/2) * (1*np.sqrt(discr) + a + d)
                    lambda_2 = (1/2) * (-1*np.sqrt(discr) + a + d)
                    vm = -((-a + d - np.sqrt(discr))/(2*c))
                    vp = -((-a + d + np.sqrt(discr))/(2*c))
                    one = np.ones(vm.shape)
                    v1 = np.array([vm, one])
                    v2 = np.array([vp, one])
                    
                else:
                    lambda_1 = (1/2) * (-1*np.sqrt(discr) + a + d)
                    lambda_2 = (1/2) * (1*np.sqrt(discr) + a + d)
                    vm = -((-a + d - np.sqrt(discr))/(2*c))
                    vp = -((-a + d + np.sqrt(discr))/(2*c))
                    one = np.ones(vm.shape)
                    v1 = np.array([vp, one])
                    v2 = np.array([vm, one])
                

                
                vec_1 = (1/la.norm(v1))*v1
                # print('***', v1, v1.shape, la.norm(v1))
                vec_2 = (1/la.norm(v2))*v2
                
                freq_1 = np.real(lambda_1)
                freq_2 = np.real(lambda_2)
                
                
                if mode_id == 1:
                    
                    D = -1*np.imag(lambda_1)

                    Da_prime = (1/2)*(2*D + Delta_root)
                    Db_prime = (1/2)*(2*D - Delta_root)
                    
                    plt.plot(line_Da_prime(s, psi_a = vec_1[0]), line_Db_prime(s, psi_b = vec_1[1]), color = 'green')
                    plt.plot(Da_prime, Db_prime, 'x', color='black')
                    r = eigenvector_amplitude(Da, Da_prime, vec_1[0])
                    if np.isnan(r):
                        continue
            
                    frequencies.append(freq_1)
                    eigenvectors.append(vec_1)
                    rs.append(r)
                
                if mode_id == 2:
                    
                    D = -1*np.imag(lambda_2)
                    Da_prime = (1/2)*(2*D + Delta_root)
                    Db_prime = (1/2)*(2*D - Delta_root)
                    
                    plt.plot(line_Da_prime(s, psi_a = vec_2[0]), line_Db_prime(s, psi_b = vec_2[1]), color = 'orange')
                    plt.plot(Da_prime, Db_prime, 'x', color = 'black')
                    
                    r = eigenvector_amplitude(Da, Da_prime, vec_2[0])
                    if np.isnan(r):
                        continue
            
                    frequencies.append(freq_2)
                    eigenvectors.append(vec_2)
                    rs.append(r)
            
            plt.plot(Da, Db, 'o', color = 'blue')
            # plt.xlabel(r'$D_A$')
            # plt.ylabel(r'$D_B$')
            plt.xlabel('Pump in Disk A')
            plt.ylabel('Pump in Disk B')
            plt.xlim(0,10)
            plt.ylim(0,10)
            plt.gca().set_aspect('equal')
            plt.grid()
            plt.legend()
            plt.show()
            
        if Plot == False: # Don't want to always see the clamping plots
            
            # iterate the implicit function over points on the threshold lines to find turning points
            
            def implicit_function(Da_prime, Db_prime, Da, Db):
                    psi_a = self.values_vectors(Da_prime, Db_prime, Da_prime, Db_prime)[0][1][0]
                    psi_b = self.values_vectors(Da_prime, Db_prime, Da_prime, Db_prime)[0][1][1]
                    f = Db_prime*(np.abs(psi_b)**2)*(Da_prime - Da) + Da_prime*(np.abs(psi_a)**2)*(Db - Db_prime)
                    return f
            
            if mode_id == 1:
                    
                Da_prime_new_1 = [] # 1 and 2 here refer to point 1 and point 2 i.e. consecutive points, not modes 1 and 2
                Db_prime_new_1 = []
                Da_prime_new_2 = []
                Db_prime_new_2 = []
                    
                for i in range(1,len(Db_prime_1_old)):
                    f = implicit_function(Da_prime_1_old[i], Db_prime_1_old[i], Da, Db)
                    f_minus = implicit_function(Da_prime_1_old[i-1], Db_prime_1_old[i-1], Da, Db)
                    # if np.sign(f) != np.sign(f_minus):
                    if (f < 0 and f_minus >= 0) or (f >= 0 and f_minus < 0):
                        Da_prime_new_1.append(Da_prime_1_old[i-1])
                        Db_prime_new_1.append(Db_prime_1_old[i-1])
                        Da_prime_new_2.append(Da_prime_1_old[i])
                        Db_prime_new_2.append(Db_prime_1_old[i])
                        
                        
            if mode_id == 2:
                    
                Da_prime_new_1 = [] # 1 and 2 here refer to point 1 and point 2 i.e. consecutive points, not modes 1 and 2
                Db_prime_new_1 = []
                Da_prime_new_2 = []
                Db_prime_new_2 = []
                    
                for i in range(1,len(Db_prime_2_old)):
                    f = implicit_function(Da_prime_2_old[i], Db_prime_2_old[i], Da, Db)
                    f_minus = implicit_function(Da_prime_2_old[i-1], Db_prime_2_old[i-1], Da, Db)
                    # if np.sign(f) != np.sign(f_minus):
                    if (f < 0 and f_minus >= 0) or (f >= 0 and f_minus < 0):
                        Da_prime_new_1.append(Da_prime_2_old[i-1])
                        Db_prime_new_1.append(Db_prime_2_old[i-1])
                        Da_prime_new_2.append(Da_prime_2_old[i])
                        Db_prime_new_2.append(Db_prime_2_old[i])
                        
            # use average values to roughly identify turning point
            # avergae values will be used as initial guesses for fsolve            
            Da_prime_bar = (np.array(Da_prime_new_2) + np.array(Da_prime_new_1))/2  
            Db_prime_bar = (np.array(Db_prime_new_2) + np.array(Db_prime_new_1))/2
            
            def mode_condition(Delta, omega_a, omega_b, gamma_a, gamma_b, kappa_ab, kappa_ba, phi_ab, phi_ba, Da, Db):
                
                a = omega_a - 1j*gamma_a + 1j*(Delta/2)
                b = kappa_ab * np.exp(1j * phi_ab)
                c = kappa_ba * np.exp(1j * phi_ba)
                d = omega_b - 1j*gamma_b - 1j*(Delta/2)
                
                discr = a**2 - 2*a*d + 4*b*c + d**2
                
                kr = np.real(4*b*c)
                ki = np.imag(4*b*c)
                delta = np.real(a - d)
                
                if (delta != 0 and np.imag(discr) < 0 and (kr + delta**2 - (ki/2/delta)**2) < 0) or (delta == 0 and ki == 0 and kr > 0 and np.real(discr) < 0 and np.imag(a-d) > 0):
                    lambda_1 = (1/2) * (1*np.sqrt(discr) + a + d)
                    lambda_2 = (1/2) * (-1*np.sqrt(discr) + a + d)
                    vm = -((-a + d - np.sqrt(discr))/(2*c))
                    vp = -((-a + d + np.sqrt(discr))/(2*c))
                    one = np.ones(vm.shape)
                    v1 = np.array([vm, one])
                    v2 = np.array([vp, one])
                    
                else:
                    lambda_1 = (1/2) * (-1*np.sqrt(discr) + a + d)
                    lambda_2 = (1/2) * (1*np.sqrt(discr) + a + d)
                    vm = -((-a + d - np.sqrt(discr))/(2*c))
                    vp = -((-a + d + np.sqrt(discr))/(2*c))
                    one = np.ones(vm.shape)
                    v1 = np.array([vp, one])
                    v2 = np.array([vm, one])
                

                
                vec_1 = (1/la.norm(v1))*v1
                vec_2 = (1/la.norm(v2))*v2
                
                
                
                    
                if mode_id == 1:
                    
                    psi_a = vec_1[0]
                    psi_b = vec_1[1]
                    
                    D = -1*np.imag(lambda_1)
                    
                    Da_prime = (1/2)*(2*D + Delta)
                    Db_prime = (1/2)*(2*D - Delta)
                    
                    f = Db_prime*(np.abs(psi_b)**2)*(Da_prime - Da) + Da_prime*(np.abs(psi_a)**2)*(Db - Db_prime)
                    return f
                
                if mode_id == 2:
                    
                    psi_a = vec_2[0]
                    psi_b = vec_2[1]
                    
                    D = -1*np.imag(lambda_2)
                    
                    Da_prime = (1/2)*(2*D + Delta)
                    Db_prime = (1/2)*(2*D - Delta)
                    
                    f = Db_prime*(np.abs(psi_b)**2)*(Da_prime - Da) + Da_prime*(np.abs(psi_a)**2)*(Db - Db_prime)
                    return f
            
            def line_Da_prime(r, psi_a):
                    Da = Da_prime*(1 + r**2*np.abs(psi_a)**2)
                    return Da
                
            def line_Db_prime(r, psi_b):
                Db = Db_prime*(1 + r**2*np.abs(psi_b)**2)
                return Db
            
            def eigenvector_amplitude(Da, Da_prime, psi_a):
                r = np.sqrt(((Da/Da_prime) - 1)/(np.abs(psi_a)**2))
                return r
            
            s = np.linspace(0,10,100)
            
            frequencies = []
            eigenvectors = []
            rs = []
            
            for i in range(len(Da_prime_bar)):
                
                initial_guess = Da_prime_bar[i] - Db_prime_bar[i] # Delta is differential pump
                
                Delta_root = op.fsolve(mode_condition, [initial_guess], args=(omega_a, omega_b, gamma_a, gamma_b, kappa_ab, kappa_ba, phi_ab, phi_ba, Da, Db))
                
                a = omega_a - 1j*gamma_a + 1j*(Delta_root/2)
                b = kappa_ab * np.exp(1j * phi_ab)
                c = kappa_ba * np.exp(1j * phi_ba)
                d = omega_b - 1j*gamma_b - 1j*(Delta_root/2)
                
                discr = a**2 - 2*a*d + 4*b*c + d**2
                
                kr = np.real(4*b*c)
                ki = np.imag(4*b*c)
                delta = np.real(a - d)
            
                if (delta != 0 and np.imag(discr) < 0 and (kr + delta**2 - (ki/2/delta)**2) < 0) or (delta == 0 and ki == 0 and kr > 0 and np.real(discr) < 0 and np.imag(a-d) > 0):
                    lambda_1 = (1/2) * (1*np.sqrt(discr) + a + d)
                    lambda_2 = (1/2) * (-1*np.sqrt(discr) + a + d)
                    vm = -((-a + d - np.sqrt(discr))/(2*c))
                    vp = -((-a + d + np.sqrt(discr))/(2*c))
                    one = np.ones(vm.shape)
                    v1 = np.array([vm, one])
                    v2 = np.array([vp, one])
                    
                else:
                    lambda_1 = (1/2) * (-1*np.sqrt(discr) + a + d)
                    lambda_2 = (1/2) * (1*np.sqrt(discr) + a + d)
                    vm = -((-a + d - np.sqrt(discr))/(2*c))
                    vp = -((-a + d + np.sqrt(discr))/(2*c))
                    one = np.ones(vm.shape)
                    v1 = np.array([vp, one])
                    v2 = np.array([vm, one])
                

                
                vec_1 = (1/la.norm(v1))*v1
                vec_2 = (1/la.norm(v2))*v2
                
                freq_1 = np.real(lambda_1)
                freq_2 = np.real(lambda_2)
                
                
                if mode_id == 1:
                    
                    D = -1*np.imag(lambda_1)
                    Da_prime = (1/2)*(2*D + Delta_root)
                    Db_prime = (1/2)*(2*D - Delta_root)
                    
                    r = eigenvector_amplitude(Da, Da_prime, vec_1[0])
                    if np.isnan(r):
                        continue
            
                    frequencies.append(freq_1)
                    eigenvectors.append(vec_1)
                    rs.append(r)
                    
                
                if mode_id == 2:
                    
                    D = -1*np.imag(lambda_2)
                    Da_prime = (1/2)*(2*D + Delta_root)
                    Db_prime = (1/2)*(2*D - Delta_root)
                    
                    r = eigenvector_amplitude(Da, Da_prime, vec_2[0])
                    if np.isnan(r):
                        continue
            
                    frequencies.append(freq_2)
                    eigenvectors.append(vec_2)
                    rs.append(r)
        
        return frequencies, rs, eigenvectors
        
        
    
    
    def Lasing_Mode_Frequencies(self, Da, Db):
        
        mode_1_frequencies, mode_1_rs, mode_1_eigenvectors = self.Lasing_Mode_Selection(Da, Db, mode_id=1, Plot=False)
        mode_2_frequencies, mode_2_rs, mode_2_eigenvectors = self.Lasing_Mode_Selection(Da, Db, mode_id=2, Plot=False)
        
        plt.figure(num=3)
        
        for i in range(len(mode_1_frequencies)):
            plt.plot(mode_1_frequencies[i], mode_1_rs[i]**2, 'o', color='green', label = 'Mode 1')
            plt.plot([mode_1_frequencies[i], mode_1_frequencies[i]], [mode_1_rs[i]**2, 0], '--', color='green')
        
        for i in range(len(mode_2_frequencies)):
            plt.plot(mode_2_frequencies[i], mode_2_rs[i]**2, 'o', color = 'orange', label = 'Mode 2')
            plt.plot([mode_2_frequencies[i], mode_2_frequencies[i]], [mode_2_rs[i]**2, 0], '--', color='orange')
        
        plt.xlabel('Frequency Shift')
        plt.ylabel('Intensity')
        # plt.yticks(ticks = np.arange(0,9, step = 8))
        # plt.title(r'Lasing Modes $D_A =$' + str(Da) + r', $D_B =$' + str(Db))
        # plt.grid()
        import matplotlib.patches as mpatches
        green_patch = mpatches.Patch(color='green', label='Mode 1')
        orange_patch = mpatches.Patch(color='orange', label='Mode 2')
        plt.legend(handles=[green_patch, orange_patch])
        # plt.legend()
        plt.show()
        
    
    def stability(self, Da, Db, Output=False, mode_1=False, mode_2=False):
        
                
        """
        Unstable modes are plotted in red, stable modes are plotted in blue
        Jacobian Analysis used
        """
        
        omega_a = self._omega_a
        omega_b = self._omega_b
        gamma_a = self._gamma_a
        gamma_b = self._gamma_b
        
        kappa_ab = self._kappa_ab*np.exp(1j*self._phi_ab)
        kappa_ba = self._kappa_ba*np.exp(1j*self._phi_ba)
        
        
        def Jacobian(omega_a, omega_b, gamma_a, gamma_b, Da, Db, kappa_ab, kappa_ba, psi_a, psi_b, r, omega):
            
            real_psi_a = r*np.real(psi_a)
            imag_psi_a = r*np.imag(psi_a)
            real_psi_b = r*np.real(psi_b)
            imag_psi_b = r*np.imag(psi_b)
            
            
            def d_func1d_real(real_psi, imag_psi, gamma, D):
                a = -gamma
                b = D
                x = real_psi
                y = imag_psi
                f = a + b*(-(x**2) + y**2 + 1)/((x**2 + (y**2) + 1)**2)
                return f
            
            def d_func1d_imag(real_psi, imag_psi, gamma, D):
                a = -gamma
                b = D
                x = imag_psi
                y = real_psi
                f = a + b*(-(x**2) + y**2 + 1)/((x**2 + (y**2) + 1)**2)
                return f
            
            def d_func2d_real(real_psi, imag_psi, gamma, D):
                a = -gamma
                b = D
                x = real_psi
                y = imag_psi
                f = (-2*b*x*y)/((x**2 + (y**2) + 1)**2)
                return f
            
            def d_func2d_imag(real_psi, imag_psi, gamma, D):
                a = -gamma
                b = D
                x = imag_psi
                y = real_psi
                f = (-2*b*x*y)/((x**2 + (y**2) + 1)**2)
                return f
            
            
            J = np.zeros((4, 4), dtype='complex128')

            J[...,0,0] = d_func1d_real(real_psi_a, imag_psi_a, gamma_a, Da)
            J[...,0,1] = (omega_a - omega) + d_func2d_imag(real_psi_a, imag_psi_a, gamma_a, Da)
            J[...,0,2] = np.imag(kappa_ab)
            J[...,0,3] = np.real(kappa_ab)
            
            J[...,1,0] = -(omega_a - omega) + d_func2d_real(real_psi_a, imag_psi_a, gamma_a, Da)
            J[...,1,1] = d_func1d_imag(real_psi_a, imag_psi_a, gamma_a, Da)
            J[...,1,2] = -np.real(kappa_ab)
            J[...,1,3] = np.imag(kappa_ab)
            
            J[...,2,0] = np.imag(kappa_ba)
            J[...,2,1] = np.real(kappa_ba)
            J[...,2,2] = d_func1d_real(real_psi_b, imag_psi_b, gamma_b, Db)
            J[...,2,3] = (omega_b - omega) + d_func2d_real(real_psi_b, imag_psi_b, gamma_b, Db)
            
            J[...,3,0] = -np.real(kappa_ba)
            J[...,3,1] = np.imag(kappa_ba)
            J[...,3,2] = -(omega_b - omega) + d_func2d_imag(real_psi_b, imag_psi_b, gamma_b, Db)
            J[...,3,3] = d_func1d_imag(real_psi_b, imag_psi_b, gamma_b, Db)

            if np.any(np.isnan(J)) == True:
                return 0
            
            else:
                val, vec = la.eig(J)

                if np.all(np.real(val) < 1e-6):
                    return 1
                else:
                    return 0
        
            
        if Output == False:
            
            mode_1_frequencies, mode_1_rs, mode_1_eigenvectors = self.Lasing_Mode_Selection(Da, Db, mode_id = 1, Plot=True, fig_num = 1)
            mode_2_frequencies, mode_2_rs, mode_2_eigenvectors = self.Lasing_Mode_Selection(Da, Db, mode_id = 2, Plot=True, fig_num = 2)
    
            plt.figure(num=4) 
            plt.title('Mode Stability')
        
            for i in range(len(mode_1_frequencies)):
                
                omega = mode_1_frequencies[i]
                psi_a = mode_1_eigenvectors[i][0]
                psi_b = mode_1_eigenvectors[i][1]
                r = mode_1_rs[i]
                
                val = Jacobian(
                    omega_a, omega_b, gamma_a, gamma_b, Da, Db,
                    kappa_ab, kappa_ba, psi_a, psi_b, r, omega
                    )
                
                if val == 1:
                    # print('stable mode 1:', psi_a, psi_b, r)
                    plt.plot(mode_1_frequencies[i], mode_1_rs[i]**2, 'o', color = 'blue', label = 'Stable')
                    plt.plot([mode_1_frequencies[i], mode_1_frequencies[i]], [mode_1_rs[i]**2, 0], '--', color = 'blue')
                
                if val == 0:
                    # print('unstable mode 1:', psi_a, psi_b, r)
                    plt.plot(mode_1_frequencies[i], mode_1_rs[i]**2, 'o', color = 'red', label = 'Unstable')
                    plt.plot([mode_1_frequencies[i], mode_1_frequencies[i]], [mode_1_rs[i]**2, 0], '--', color = 'red')
                    
                
            
            for i in range(len(mode_2_frequencies)):
                
                omega = mode_2_frequencies[i]
                psi_a = mode_2_eigenvectors[i][0]
                psi_b = mode_2_eigenvectors[i][1]
                r = mode_2_rs[i]
                
                val = Jacobian(omega_a, omega_b, gamma_a, gamma_b, Da, Db, kappa_ab, kappa_ba, psi_a, psi_b, r, omega)
                
                if val == 1:
                    # print('stable mode 2:', psi_a, psi_b, r)
                    plt.plot(mode_2_frequencies[i], mode_2_rs[i]**2, 'o', color = 'blue', label = 'Stable')
                    plt.plot([mode_2_frequencies[i], mode_2_frequencies[i]], [mode_2_rs[i]**2, 0], '--', color = 'blue')
                
                if val == 0:
                    # print('unstable mode 2:', psi_a, psi_b, r)
                    plt.plot(mode_2_frequencies[i], mode_2_rs[i]**2, 'o', color = 'red', label = 'Unstable')
                    plt.plot([mode_2_frequencies[i], mode_2_frequencies[i]], [mode_2_rs[i]**2, 0], '--', color = 'red')
                
            
            plt.xlabel('Frequency Shift')
            plt.ylabel('Intensity')
            plt.title('Mode Stability $D_A =$' + str(Da) + r', $D_B =$' + str(Db))
            plt.yticks(ticks = np.arange(0,9, step = 8))
            # plt.grid()
            import matplotlib.patches as mpatches
            red_patch = mpatches.Patch(color='red', label='Unstable')
            blue_patch = mpatches.Patch(color='blue', label='Stable')
            plt.legend(handles=[blue_patch, red_patch])
            #plt.legend()
            plt.show()
            
        if Output==True:
            
            if mode_1==True:
            
                mode_1_frequencies, mode_1_rs, mode_1_eigenvectors = self.Lasing_Mode_Selection(Da, Db, mode_id = 1, Plot=False)
                mode_1_stabilities = []
                # print(Da, 'mode 1', mode_1_frequencies)

                for i in range(len(mode_1_frequencies)):
                
                    omega = mode_1_frequencies[i]
                    psi_a = mode_1_eigenvectors[i][0]
                    psi_b = mode_1_eigenvectors[i][1]
                    r = mode_1_rs[i]
                
                    val = Jacobian(omega_a, omega_b, gamma_a, gamma_b, Da, Db, kappa_ab, kappa_ba, psi_a, psi_b, r, omega)
                    mode_1_stabilities.append(val)
                return mode_1_stabilities, mode_1_rs #mode_1_frequencies
                        
            
            if mode_2==True:
                
                mode_2_frequencies, mode_2_rs, mode_2_eigenvectors = self.Lasing_Mode_Selection(Da, Db, mode_id = 2, Plot=False)
                mode_2_stabilities = [] 
                # print(Da, 'mode 2', mode_2_frequencies)
                
                for i in range(len(mode_2_frequencies)):
                    
                    omega = mode_2_frequencies[i]
                    psi_a = mode_2_eigenvectors[i][0]
                    psi_b = mode_2_eigenvectors[i][1]
                    r = mode_2_rs[i]
                    
                    val = Jacobian(omega_a, omega_b, gamma_a, gamma_b, Da, Db, kappa_ab, kappa_ba, psi_a, psi_b, r, omega)
                    mode_2_stabilities.append(val)
                return mode_2_stabilities, mode_2_rs #mode_2_frequencies
        
    
    def stability_map_mode_1(self, iterations=21):
        
        Da_prime_1_thresh, Db_prime_1_thresh, Da_prime_2_thresh, Db_prime_2_thresh = self.threshold_lines()
        
        plt.figure(num=7)
        plt.title('Mode 1 Stability Map')
        plt.plot(Da_prime_1_thresh, Db_prime_1_thresh)#, label = 'Mode 1 Lasing Boundary')
        plt.plot(Da_prime_2_thresh, Db_prime_2_thresh)#, label = 'Mode 2 Lasing Boundary')
        
        #Db = np.linspace(Db_prime_1_thresh,10,iterations)
        
        for j in tqdm(range(len(Db_prime_1_thresh))):
            Da = np.linspace(Da_prime_1_thresh[j], 10, iterations)
            for k in range(len(Da)):
                self.stability(Da[k], Db_prime_1_thresh[j], Output=True, mode_1=True)
                        
        plt.xlabel(r'$D_A$')
        plt.ylabel(r'$D_B$')
        plt.gca().set_aspect('equal')
        plt.grid()
        plt.xlim(0,10)
        plt.ylim(0,10)
            
        plt.show()
        
    
    def stability_map_mode_2(self, iterations=21):
        
        Da_prime_1_thresh, Db_prime_1_thresh, Da_prime_2_thresh, Db_prime_2_thresh = self.threshold_lines()
        
        plt.figure(num=8)
        plt.title('Mode 2 Stability Map')
        plt.plot(Da_prime_1_thresh, Db_prime_1_thresh)#, label = 'Mode 1 Lasing Boundary')
        plt.plot(Da_prime_2_thresh, Db_prime_2_thresh)#, label = 'Mode 2 Lasing Boundary')
        
        Db = np.linspace(max(Db_prime_2_thresh), np.sqrt(200),iterations)
        phi = np.linspace(0, np.pi/2, iterations)
        
        # Das = []
        # Dbs = []
        # Z = []
        
        for j in tqdm(range(len(Db))):
            for k in range(len(phi)):
                r = Db[j] + 0.5
                Da_2 = r*np.cos(phi[k])
                Db_2 = r*np.sin(phi[k])
                self.stability(Da_2, Db_2, Output=True, mode_2=True)

                # if self.stability(Da_2, Db_2, Output=True, mode_2=True) == None:
                #     continue
                # Da_final, Db_final, z = self.stability(Da_2, Db_2, Output=True, mode_2=True)
                
                # Da_2, Db_2, z = self.stability(Da[j], Db[k], Output=True, mode_2=True)
                    
                # if np.isnan(z) == True:
                #     continue
                # else:
                #     Das.append(Da_final)
                #     Dbs.append(Db_final)
                #     Z.append(z)
        
        # plt.tricontourf(Das, Dbs, np.array(Z).flatten(), levels = 100, cmap = 'inferno_r')
        # plt.colorbar(label='Mode Intensity')
        plt.xlabel(r'$D_A$')
        plt.ylabel(r'$D_B$')
        plt.gca().set_aspect('equal')
        plt.grid()
        plt.xlim(0,10)
        plt.ylim(0,10)
            
        plt.show()
                    
                    
    
                    
    
    def threshold_line_plot(self):
        
        def func(x):
            y = x
            return y
        
        def func_2(x):
            y = (3/7)*x
            return y
        
        a, b, c, d = self.threshold_lines(N=1001)
    
        # x = np.linspace(0,10,101)

        plt.plot(a, b, color = 'green', label = 'Mode 1 Threshold')
        plt.plot(c, d, color = 'orange', label = 'Mode 2 Threshold')
        # plt.plot(a, b, label = 'Mode 1 Threshold')
        # plt.plot(c, d, label = 'Mode 2 Threshold')
        # plt.plot([2.5, 2.5], [0, 10], '--', color = 'orange', label = 'Disk A Threshold')
        # plt.plot([0, 10], [2.5, 2.5], '--', color = 'green', label = 'Disk B Threshold')
        # plt.plot([2.5, 2.5], [0, 10], '--', label = 'Disk A Threshold')
        # plt.plot([0, 10], [2.5, 2.5], '--', label = 'Disk B Threshold')
        # plt.plot(8,8, 'o', color='black')
        # plt.plot(x, func(x), '--', color = 'red')
        # plt.plot(x, func_2(x), '--', color = 'red')
        # plt.plot([0,3.5],[0,1.5], '--', color='blue', label = 'virtual EP')
        # plt.plot([0,1.5],[0,3.5], '--', color='blue')
        # plt.plot(1.5,3.5,'o', color='black', label = 'EP')
        # plt.plot(3.5,1.5,'o', color='green')
        # plt.plot([0,10], [0,10], 'k--')
        plt.xlim(0,10)
        plt.ylim(0,10)
        # plt.xlabel(r'$D_A$')
        # plt.ylabel(r'$D_B$')
        plt.xlabel('Pump in Disk A')
        plt.ylabel('Pump in Disk B')
        plt.xticks(ticks=np.arange(0,11, step=10))
        plt.yticks(ticks=np.arange(0,11, step=10))
        plt.gca().set_aspect('equal')
        # plt.grid()
        plt.title('Coupled Threshold Lines')
        plt.legend(loc=1)
        plt.show()
        
    def separation_vs_phi(self, points = 21):
        
        def separation(Da_1, Db_1, Da_2, Db_2):
            
            delta_a = np.array(Da_2) - np.array(Da_1)
            delta_b = np.array(Db_2) - np.array(Db_1)
            separation = np.sqrt(delta_a**2 + delta_b**2)
            
            separation = separation[~np.isnan(separation)]
            
            return np.min(separation)
        
        phi = np.linspace(0, 2*np.pi, points)
        
        delta = []
        
        for i in tqdm(range(len(phi))):
            Da_1, Db_1, Da_2, Db_2 = self.threshold_lines(phi = phi[i])
            ds = separation(Da_1, Db_1, Da_2, Db_2)
            delta.append(ds)
            
        
        plt.plot(phi, delta)
        plt.xlabel(r'$\phi$')
        plt.ylabel('Minimum Threshold Line Separation')
        plt.xticks(ticks = np.arange(0,7, np.pi/2), labels = [r'0', '$\pi/2$', '$\pi$', '$3\pi/2$', '$2\pi$'])
        plt.yticks(ticks=np.arange(0,3,step = 2.5))
        # plt.grid()
        plt.show()
        
    def min_phi(self):
        
        def separation(phi):
            Da_1, Db_1, Da_2, Db_2 = self.threshold_lines(phi = phi)
            
            delta_a = np.array(Da_2) - np.array(Da_1)
            delta_b = np.array(Db_2) - np.array(Db_1)
            separation = np.sqrt(delta_a**2 + delta_b**2)
            
            separation = separation[~np.isnan(separation)]
            
            return np.min(separation)
        
        phi_min = op.fsolve(separation, np.pi/65)
        return phi_min[0]
    
    
    
    def experimental_plots(self):
        
        if type(self._Da) != int and type(self._Da) != float:
                print('Fix the pumping in disk A')
            
        else:
        
            
            val_1, val_2, vec_1, vec_2 = self.matrix_solve()
            
            x1 = np.real(val_1)
            y1 = np.imag(val_1)
            x2 = np.real(val_2)
            y2 = np.imag(val_2)
            beta = self._Db - self._gamma_b # beta is the net input
            
            points_1 = np.array([x1, y1]).T.reshape(-1, 1, 2)
            segments_1 = np.concatenate([points_1[:-1], points_1[1:]], axis=1)
    
            points_2 = np.array([x2, y2]).T.reshape(-1, 1, 2)
            segments_2 = np.concatenate([points_2[:-1], points_2[1:]], axis=1)
    
            fig, ax = plt.subplots(1,1, figsize=[15,10])
            
            # plt.plot([0, 0], [-1, 1], 'k--', zorder=-100)
            plt.plot([-1, 1], [0, 0], 'k--', zorder=-100, label = 'Threshold')
            
            # Create a continuous norm to map from data points to colors
            norm = plt.Normalize(beta.min(), beta.max())
            lc_1 = LineCollection(segments_1, cmap='jet', norm=norm)
            # Set the values used for colormapping
            lc_1.set_array(beta)
            lc_1.set_linewidth(5)
            line = ax.add_collection(lc_1)
            
            #norm = plt.Normalize(beta.min(), beta.max())
            lc_2 = LineCollection(segments_2, cmap='jet')#, norm=norm)
            # Set the values used for colormapping
            lc_2.set_array(beta)
            lc_2.set_linewidth(5)
            line = ax.add_collection(lc_2)
            fig.colorbar(line, ax=ax, label = 'Pump in Disk B')
            
            ax.set_xlim(-.2, .2)
            ax.set_ylim(-.4, .15)
            ax.set_xlabel(r'$Re[\omega]$')
            ax.set_ylabel(r'$Im[\omega]$')
            ax.set_title('Movement of Complex Eigenvalues')
            #plt.tight_layout()
            plt.legend()
            plt.grid()
            plt.show()
        
            
            freq_1 = np.real(val_1[0])
            gain_1 = np.imag(val_1[0])
            freq_1[gain_1<0] = np.nan
            
            # print(freq_1.shape)
    
            freq_2 = np.real(val_2[0])
            gain_2 = np.imag(val_2[0])
            freq_2[gain_2<0] = np.nan
    
            maxg = max(gain_1.max(), gain_2.max())
    
            points_1 = np.array([freq_1, self._Db]).T.reshape(-1, 1, 2)
            segments_1 = np.concatenate([points_1[:-1], points_1[1:]], axis=1)
    
            points_2 = np.array([freq_2, self._Db]).T.reshape(-1, 1, 2)
            segments_2 = np.concatenate([points_2[:-1], points_2[1:]], axis=1)
    
    
            fig, ax = plt.subplots(1,1, figsize=[8,8])
    
    
            # Create a continuous norm to map from data points to colors
            norm = plt.Normalize(0, maxg)
            lc_1 = LineCollection(segments_1, cmap='jet', norm=norm)
            # Set the values used for colormapping
            lc_1.set_array(gain_1)
            lc_1.set_linewidth(5)
            line = ax.add_collection(lc_1)
    
            norm = plt.Normalize(0, maxg)
            lc_2 = LineCollection(segments_2, cmap='jet', norm=norm)
            # Set the values used for colormapping
            lc_2.set_array(gain_2)
            lc_2.set_linewidth(5)
            line = ax.add_collection(lc_2)
    
            cb = fig.colorbar(line, ax=ax)
            cb.set_label("Mode Gain")
            plt.xlim(-.2, .2)
            plt.ylim(.5, 1.2)
            ax.set_xlabel(r'$\omega$')
            ax.set_ylabel(r'$D_B$')
            ax.set_title('Emission Spectrum')
            
            plt.grid()
    #        plt.tight_layout()
            plt.show()
            
            # stability frequency plot
            
    def stability_frequency_plot(self):
        
        # Da = np.linspace(1,5,2)
        Da = np.linspace(0,10,101)
        
        # def Db(Da):
        #     Db = (3/7)*Da
        #     return Db
        
        for i in range(len(Da)):

            # stability_1, frequencies_1 = self.stability(Da[i], Da[i], Output=True, mode_1=True)
            # stability_2, frequencies_2 = self.stability(Da[i], Da[i], Output=True, mode_2 = True)
            # for j in range(len(frequencies_1)):
            #     if stability_1[j] == 0:
            #         plt.plot(frequencies_1[j], Da[i], 'o', color = 'red')
            #     if stability_1[j] == 1:
            #         plt.plot(frequencies_1[j], Da[i], 'o', color = 'blue')
                    
            # for j in range(len(frequencies_2)):
            #     if stability_2[j] == 0:
            #         plt.plot(frequencies_2[j], Da[i], 'o', color = 'red')
            #     if stability_2[j] == 1:
            #         plt.plot(frequencies_2[j], Da[i], 'o', color = 'blue')
            
            stability_1, rs_1 = self.stability(Da[i], Da[i], Output=True, mode_1=True)
            stability_2, rs_2 = self.stability(Da[i], Da[i], Output=True, mode_2 = True)
            # if len(stability_1) != 0:
            for j in range(len(rs_1)):
                if stability_1[j] == 0:
                    plt.plot(np.abs(rs_1[j])**2, Da[i], 'o', color = 'red')
                if stability_1[j] == 1:
                    plt.plot(np.abs(rs_1[j])**2, Da[i], 'o', color = 'blue')
            
            # if len(stability_2) != 0:
            for j in range(len(rs_2)):
                if stability_2[j] == 0:
                    plt.plot(np.abs(rs_2[j])**2, Da[i], 'o', color = 'red')
                if stability_2[j] == 1:
                    plt.plot(np.abs(rs_2[j])**2, Da[i], 'o', color = 'blue')
        

        plt.ylim(0,10)
        # plt.xlim(-1.1,1.1)
        # plt.xlabel('Frequency Shift')
        plt.xlabel('Mode Intensity')
        plt.ylabel('Pump in Disks A and B')
        # plt.plot([-1.2,1.2], [2.5,2.5], '--', color = 'black',label = 'Threshold')
        # plt.xticks(ticks=np.arange(-1,2, step=1))
        plt.yticks(ticks=np.arange(0,11, step=10))
        import matplotlib.patches as mpatches
        red_patch = mpatches.Patch(color='red', label='Unstable')
        blue_patch = mpatches.Patch(color='blue', label='Stable')
        plt.legend(handles=[blue_patch, red_patch])
        # plt.legend()
        # plt.title(r'$\phi$ = ' + str(self._phi_ab))
        # plt.title(r'$\phi$ = $\pi/3$')
        # plt.title('Complex Coupling')
        plt.show()
            
         
         
         
         
         
    # def geometric_method_mode_1(self, Da, Db):
        
    #     Da_prime_1, Db_prime_1, Da_prime_2, Db_prime_2 = self.threshold_lines(N=1001)
        
    #     r = np.linspace(0,10,100)
        
    #     shortest_distances = []
        
    #     for i in tqdm(range(len(Db_prime_1))):
        
    #         mode_1, mode_2 = self.values_vectors(Da_prime_1[i], Db_prime_1[i], Da_prime_1[i], Db_prime_1[i])
            
    #         val_1 = mode_1[0]
    #         vec_1 = mode_1[1]
    #         val_2 = mode_2[0]
    #         vec_2 = mode_2[1]
            
            
    #         def DA(r):
    #             Da = Da_prime_1[i]*(1 + (r**2)*np.abs(vec_1[0])**2)
    #             return Da
        
    #         def DB(r):
    #             Db = Db_prime_1[i]*(1 + (r**2)*np.abs(vec_1[1])**2)
    #             return Db

    #         for j in range(1,len(r)): #cycle over points on the line to find perpendicular distance to the pump point
    #             distance_minus = np.sqrt((DA(r[j-1]) - Da)**2 + (DB(r[j-1]) - Db)**2)
    #             distance = np.sqrt((DA(r[j]) - Da)**2 + (DB(r[j]) - Db)**2)
    #             if distance > distance_minus:
    #                 R = (r[j] + r[j-1])/2
        
    #         shortest_distances.append(np.sqrt((DA(R) - Da)**2 + (DB(R) - Db)**2))
        
    #     # sort the primed variables in order of their shortest distance to the point
        
    #     Da_sort = [x for _, x in sorted(zip(shortest_distances, Da_prime_1), key=lambda pair: pair[0])] #sort D_prime lists in order of shortest distance
    #     Db_sort = [x for _, x in sorted(zip(shortest_distances, Db_prime_1), key=lambda pair: pair[0])]
         
    #     Da_prime_bar = (Da_sort[0] + Da_sort[1])/2 # we assume that the lines with the 4 shortest distances
    #     Db_prime_bar = (Db_sort[0] + Db_sort[1])/2 # form a quadrilateral around the point we calculate the primed values by calculating averages
        
    #     new_mode_1, new_mode_2 = self.values_vectors(Da_prime_bar, Db_prime_bar, Da_prime_bar, Db_prime_bar)
        
    #     new_val_1 = new_mode_1[0]
    #     new_vec_1 = new_mode_1[1]
    #     new_val_2 = new_mode_2[0]
    #     new_vec_2 = new_mode_2[1]
        
    #     def eigenvector_amplitude(Da, Da_prime, psi_a):
    #                 r = np.sqrt(((Da/Da_prime) - 1)/(np.abs(psi_a)**2))
    #                 return r
                
    #     r = eigenvector_amplitude(Da, Da_prime_bar, new_vec_1[0])
        
    #     return np.real(new_val_1), r, new_vec_1






